sum([], 0).
sum([H|T], Sum) :-
   sum(T, Rest),
   Sum is H + Rest.